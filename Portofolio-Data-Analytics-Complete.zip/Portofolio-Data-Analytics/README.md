
# 💼 Data Analytics & Machine Learning Portfolio

Hi! I'm a data enthusiast with a passion for turning raw data into meaningful insights.
This portfolio showcases my hands-on experience in data cleaning, analysis, visualization, and machine learning using Python.

---

## 📊 Projects

### 1. Titanic Survival Prediction (Machine Learning)
Predicting whether a Titanic passenger survived or not using features like gender, class, and fare.

- 📄 [PDF Report](./titanic%20prediction/Laporan_Proyek_Titanic_Detail.pdf)
- 💻 [Jupyter Notebook](./titanic%20prediction/Prediksi%20Model.ipynb)

### 2. Sales Data Analysis (EDA + Visualization)
Analyzing company sales data to find trends, top-performing products, and deal size insights.

- 📄 [PDF Report](./sales%20analysis/Laporan_Analisis_Penjualan_Lengkap.pdf)
- 📊 [Presentation](./sales%20analysis/Analisis%20Data%20Penjualan%20Perusahaan.pptx)

---

## 🧰 Tools Used
- Python
- Pandas, NumPy
- Matplotlib, Seaborn
- Scikit-learn
- Jupyter Notebook

---

## 🔗 Portfolio Link (Google Drive)
For public access to the full portfolio PDF:
[bit.ly/41Qghh2](https://bit.ly/41Qghh2)
